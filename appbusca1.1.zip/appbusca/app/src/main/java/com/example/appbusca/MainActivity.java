package com.example.appbusca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startmeliActivity (View view){
        Intent meliActivity = new Intent(this, meliActivity.class);
        startActivity(meliActivity);
    }
    public void startamazonActivity (View view){
        Intent amazonActivity = new Intent(this, amazonActivity.class);
        startActivity(amazonActivity);
    }
    public void startbuscapeActivity (View view){
        Intent buscapeActivity = new Intent(this, buscapeActivity.class);
        startActivity(buscapeActivity);
    }
    public void startsobreActivity (View view){
        Intent sobreActivity = new Intent(this, sobreActivity.class);
        startActivity(sobreActivity);
    }
}
